#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

#include "nestedLoopJoin.h"
#include "sortMergeJoin.h"
#include "timer.h"

using namespace std;

int main(){

  vector<vector<int>> grades1;
  vector<vector<int>> grades2;
  vector<vector<int>> grades3;

  grades1 = {
            {1, 0},
            {22, 2},
            {28, 5},
            {31, 8},
            {31, 82},
            {44, 4},
            {58, 9}};
  grades2 = {
            {1,    2},
            {28, 103},
            {28, 104},
            {31, 101},
            {31, 102},
            {82, 142},
            {58, 107}};
  grades3 = {
            {1, 5, 2},
            {1, 1, 1},
            {8, 8, 8},
            {4, 4, 4}};
    long long avgTimeNestedLoop;
    long long avgTimeSortMerge;
/*
    for (int i = 0; i < 10000; ++i) {
        avgTimeNestedLoop= avgTimeNestedLoop + nestedLoopJoin(grades1, grades2);
    }
    cout<<setprecision (7) <<"Average time nested loop join: "<< avgTimeNestedLoop/10000 ;//<< "\n Average time sort merge join: " << avgTimeSortMerge/10000;
*/
    for (int j = 0; j < 10000; ++j) {
        cout << "running";
        avgTimeSortMerge= avgTimeSortMerge + sortMergeJoin(grades1, grades2);
    }
    cout<<setprecision (7) <<"Average time sort merge join: "<< avgTimeSortMerge/10000 ;//<< "\n Average time sort merge join: " << avgTimeSortMerge/10000;

    return 1;
}
