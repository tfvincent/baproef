#ifndef SORTMERGEJOIN_H_
#define SORTMERGEJOIN_H_

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <vector>
#include <algorithm>

#include "vectorUtil.h"

long long sortMergeJoin(vector<vector<int>>, vector<vector<int>>);

#endif //BAPROEF_SORTMERGEJOIN_H